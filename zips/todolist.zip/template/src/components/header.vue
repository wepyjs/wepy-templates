<template>
  <div class="header">
    <div class="header-text">WePY Todo List</div>
  </div>
</template>
<style lang="less">
@import '~@/common/style/variable.less';
.header {
  margin-top: 30rpx;
  font-size: 60rpx;
  text-align: center;
  color: @color;
}
</style>